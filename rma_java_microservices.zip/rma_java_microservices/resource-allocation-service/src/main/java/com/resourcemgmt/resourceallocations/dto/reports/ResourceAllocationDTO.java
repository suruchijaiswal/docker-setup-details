package com.resourcemgmt.resourceallocations.dto.reports;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ResourceAllocationDTO {
	private Long resourceId;
	private String firstName;
	private String lastName;
	private String title;
	private String skills;
	private String projectName;
	private Integer allocationPercentage;
}
